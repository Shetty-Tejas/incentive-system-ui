import React, { Component } from "react";

class FetchCustomer extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }
  render() {
    return <div />;
  }
}

export default FetchCustomer;
