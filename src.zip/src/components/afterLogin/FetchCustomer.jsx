/* eslint-disable class-methods-use-this */
import React, { Component } from "react";

class FetchCustomer extends Component {
  constructor(props) {
    super(props);
    this.state = {};
  }

  render() {
    return <div>Hello</div>;
  }
}

export default FetchCustomer;
