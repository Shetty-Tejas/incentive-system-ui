import React from "react";

function Welcome() {
  return (
    <div className="row justify-content-center">
      <h4 className="display-4">Hello Customer!</h4>
    </div>
  );
}
